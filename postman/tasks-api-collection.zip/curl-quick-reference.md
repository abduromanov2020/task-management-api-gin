# Tasks API — curl quick reference

Set up variables once:

```bash
BASE=http://localhost:8080
TOKEN="<paste-jwt-after-login>"
```

## Health

```bash
curl -sS $BASE/healthz
```

## Auth

```bash
# Register (also creates a team)
curl -sS -X POST $BASE/auth/register \
  -H 'Content-Type: application/json' \
  -d '{"email":"reviewer@example.com","password":"reviewer-password","name":"Reviewer","team_name":"Sprout"}'

# Login
curl -sS -X POST $BASE/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"reviewer@example.com","password":"reviewer-password"}'
```

Capture the token with jq:

```bash
TOKEN=$(curl -sS -X POST $BASE/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"reviewer@example.com","password":"reviewer-password"}' | jq -r .access_token)
```

## Tasks — CRUD

```bash
# Create (REQUIRES Idempotency-Key header, UUID v4)
KEY=$(uuidgen)
curl -sS -X POST $BASE/tasks \
  -H "Authorization: Bearer $TOKEN" \
  -H "Idempotency-Key: $KEY" \
  -H 'Content-Type: application/json' \
  -d '{"title":"Ship it","description":"","status":"pending","priority":"high"}'

# List (status filter + title search + pagination)
curl -sS -G $BASE/tasks \
  -H "Authorization: Bearer $TOKEN" \
  --data-urlencode 'status=pending' \
  --data-urlencode 'q=ship' \
  --data-urlencode 'page=1' \
  --data-urlencode 'limit=10'

# Get by id
curl -sS $BASE/tasks/$TASK_ID -H "Authorization: Bearer $TOKEN"

# Update (full replace of mutable fields)
curl -sS -X PUT $BASE/tasks/$TASK_ID \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"title":"updated","description":"","status":"in_progress","priority":"high"}'

# Delete (creator only)
curl -sS -X DELETE $BASE/tasks/$TASK_ID -H "Authorization: Bearer $TOKEN"

# Assign (transactional: update + task_logs insert + notification)
curl -sS -X POST $BASE/tasks/$TASK_ID/assign \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d "{\"assignee_id\":\"$ASSIGNEE_ID\"}"
```

## Idempotency proofs

### (a) Replay — same key, same body → identical 201

```bash
KEY=$(uuidgen)
BODY='{"title":"ship it","priority":"high"}'

curl -sS -X POST $BASE/tasks \
  -H "Authorization: Bearer $TOKEN" -H "Idempotency-Key: $KEY" \
  -H 'Content-Type: application/json' -d "$BODY" -w "\nHTTP %{http_code}\n"

# Repeat — expect 201 with IDENTICAL body bytes
curl -sS -X POST $BASE/tasks \
  -H "Authorization: Bearer $TOKEN" -H "Idempotency-Key: $KEY" \
  -H 'Content-Type: application/json' -d "$BODY" -w "\nHTTP %{http_code}\n"
```

### (b) Mismatch — same key, different body → 422

```bash
curl -sS -X POST $BASE/tasks \
  -H "Authorization: Bearer $TOKEN" -H "Idempotency-Key: $KEY" \
  -H 'Content-Type: application/json' \
  -d '{"title":"different body","priority":"low"}' -w "\nHTTP %{http_code}\n"
# expect HTTP 422, code IDEMPOTENCY_KEY_MISMATCH
```

### (c) Race-safety — 50 parallel calls, one fresh key → exactly 1 row

```bash
KEY=$(uuidgen)
seq 50 | xargs -P 50 -I{} curl -sS -o /dev/null -w "%{http_code}\n" \
  -X POST $BASE/tasks \
  -H "Authorization: Bearer $TOKEN" -H "Idempotency-Key: $KEY" \
  -H 'Content-Type: application/json' \
  -d '{"title":"race","priority":"medium"}' | sort | uniq -c

docker compose exec -T postgres psql -U postgres -d tasks -c \
  "SELECT count(*) FROM idempotency_keys WHERE idempotency_key='$KEY';"
# expect: 1
```

## Errors — what to expect

| Status | Code                          | Triggered by                                              |
|--------|-------------------------------|-----------------------------------------------------------|
| 401    | `UNAUTHORIZED`                | Missing/invalid Authorization header                      |
| 403    | `FORBIDDEN`                   | Cross-team assign, delete by non-creator                  |
| 404    | `NOT_FOUND`                   | Task id outside requester's team or doesn't exist         |
| 409    | `CONFLICT`                    | Email already registered                                  |
| 409    | `IDEMPOTENCY_IN_FLIGHT`       | Same key still being processed (lease alive)              |
| 422    | `VALIDATION_ERROR`            | Bad payload (validator.v10 rules)                         |
| 422    | `IDEMPOTENCY_KEY_MISMATCH`    | Same key + different request body                         |
| 429    | `RATE_LIMITED`                | Too many requests to `/auth/*`                            |
| 500    | `INTERNAL_ERROR`              | Anything unhandled (cause logged, hidden from client)     |

All error envelopes share the same shape:

```json
{
  "status":     "error",
  "code":       "TASK_NOT_FOUND",
  "message":    "Task not found",
  "details":    { },
  "timestamp":  "2026-05-22T10:00:00.123Z",
  "request_id": "5f9c4d2e-3a01-4b2c-8a91-1234567890ab"
}
```

`request_id` is echoed in the `X-Request-ID` response header on every request — paste it into a log query to find the full stack on the server side.
