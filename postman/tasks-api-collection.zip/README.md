# Tasks API — API client collections

Three drop-in collections for the three most common API clients. Each one is a single file you can drag & drop into the app's import dialog.

| File                                       | Tool                                       | Format                       |
|--------------------------------------------|--------------------------------------------|------------------------------|
| `tasks-api.postman_collection.json`        | Postman                                    | Postman Collection v2.1      |
| `tasks-api.postman_environment.json`       | Postman                                    | Postman Environment          |
| `tasks-api.insomnia.json`                  | Insomnia                                   | Insomnia Export v4           |
| `openapi.yaml` / `openapi.json`            | Swagger UI, Stoplight, Redoc, code-gen     | OpenAPI 3.0.3                |
| `tasks-api-collection.zip`                 | HTTPie                                     | data dump (zip of the above) |

## Import the OpenAPI spec

- **Postman**: File → Import → drop `openapi.yaml`. Postman generates a collection from the paths/operations automatically.
- **Insomnia**: Import Data → File → pick `openapi.yaml`.
- **HTTPie**: drop the zip; the OpenAPI files are inside (HTTPie reads Postman/Insomnia primarily, the OpenAPI files are there for tooling/code-gen).
- **Swagger UI / Redoc**: serve `openapi.yaml` from anywhere; e.g. `npx @redocly/cli preview-docs openapi.yaml`.
- **Code generation**: `openapi-generator-cli generate -i openapi.yaml -g typescript-axios -o ./client` (or any of 50+ targets).
- **The running API** also serves a Swagger UI at <http://localhost:8080/swagger/index.html> using the swaggo-generated OpenAPI 2.0 spec in `docs/`. The `openapi.yaml` here is a cleaner, hand-curated 3.0.3 version with full examples for the idempotency flows.

## Import into Postman

1. Postman → File → Import → drop `tasks-api.postman_collection.json`.
2. Repeat for `tasks-api.postman_environment.json`.
3. Top-right environment dropdown → select **Tasks API — Local**.

## Import into Insomnia

1. Insomnia → Application menu → Import/Export → Import Data → From File → pick `tasks-api.insomnia.json`.

## Import into HTTPie ([httpie.io/app](https://httpie.io/app))

1. Library → "+" → Import…
2. Drag `tasks-api-collection.zip` into the import dialog.
3. Click Next, pick a space, click Import.

> HTTPie does **not** import test scripts or pre-request scripts. Token capture in HTTPie has to be done manually: copy `access_token` from the Register/Login response and paste it into the `access_token` workspace variable.

## Demonstrating idempotency in the UI

The collections include three Create-Task requests that together prove the idempotency rubric:

1. **Create Task (idempotent)** — sends a fresh `Idempotency-Key` (Postman: `{{$randomUUID}}`, Insomnia: `{% uuid 'v4' %}`). Captures `task_id`. **Save the key from the request console.**
2. **Create Task — replay same key** — set the `idempotency_key` workspace variable to the captured value, then run this. Expected: HTTP 201 with response body byte-identical to step 1; only **one** row exists in the `tasks` table.
3. **Create Task — same key, different body** — keep the same `idempotency_key` but change the title. Expected: HTTP 422 with code `IDEMPOTENCY_KEY_MISMATCH`.

To prove concurrent safety, run the bash script in the project README's "Reviewer validation script" section — that fires 50 parallel curls and checks the DB has exactly one row.

## Workspace variables

| Variable          | Set by                | Used by                                     |
|-------------------|-----------------------|---------------------------------------------|
| `base_url`        | environment           | every request                               |
| `access_token`    | Register / Login (script captures) | every authenticated request    |
| `task_id`         | Create Task (script captures)      | Get / Update / Delete / Assign |
| `assignee_id`     | Register / Login (script captures) | Assign Task                    |
| `idempotency_key` | you (paste manually for replay)    | the two "replay" requests      |
