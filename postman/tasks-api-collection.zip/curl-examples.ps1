#requires -Version 7
<#
.SYNOPSIS
  Tasks API — end-to-end curl walkthrough (PowerShell variant for Windows).

.DESCRIPTION
  Equivalent of curl-examples.sh. Uses curl.exe (bundled with Win10/11) and
  ConvertFrom-Json instead of jq. Run after `docker compose up`.

.EXAMPLE
  ./curl-examples.ps1
  ./curl-examples.ps1 -BaseUrl http://localhost:8080
#>

param(
    [string]$BaseUrl = "http://localhost:8080"
)

$ErrorActionPreference = "Stop"
$Email    = "reviewer-$([int][double]::Parse((Get-Date -UFormat %s)))@example.com"
$Password = "reviewer-password"

function HR([string]$title) { Write-Host "`n────────── $title ──────────" -ForegroundColor Cyan }
function NewUuid { [guid]::NewGuid().ToString() }

HR "0. Healthcheck"
curl.exe -sS "$BaseUrl/healthz"; Write-Host ""

HR "1. Register"
$regJson = curl.exe -sS -X POST "$BaseUrl/auth/register" `
    -H 'Content-Type: application/json' `
    -d "{`"email`":`"$Email`",`"password`":`"$Password`",`"name`":`"Reviewer`",`"team_name`":`"Sprout`"}"
$reg = $regJson | ConvertFrom-Json
Write-Host $regJson
$token  = $reg.access_token
$userId = $reg.user.id
Write-Host "token captured: $($token.Substring(0,20))..."

HR "2. Login (sanity)"
curl.exe -sS -X POST "$BaseUrl/auth/login" `
    -H 'Content-Type: application/json' `
    -d "{`"email`":`"$Email`",`"password`":`"$Password`"}"
Write-Host ""

HR "3. Create Task with a fresh Idempotency-Key — expect 201"
$key = NewUuid
Write-Host "Idempotency-Key=$key"
$createBody = '{"title":"Ship the take-home","description":"with idempotent writes","status":"pending","priority":"high"}'
$createJson = curl.exe -sS -X POST "$BaseUrl/tasks" `
    -H "Authorization: Bearer $token" `
    -H "Idempotency-Key: $key" `
    -H 'Content-Type: application/json' `
    -d $createBody
Write-Host $createJson
$created = $createJson | ConvertFrom-Json
$taskId = $created.id
Write-Host "task_id=$taskId"

HR "4. Replay same key + same body — expect identical 201"
curl.exe -sS -X POST "$BaseUrl/tasks" `
    -H "Authorization: Bearer $token" `
    -H "Idempotency-Key: $key" `
    -H 'Content-Type: application/json' `
    -w "`nHTTP %{http_code}`n" `
    -d $createBody

HR "5. Replay same key, DIFFERENT body — expect 422 IDEMPOTENCY_KEY_MISMATCH"
curl.exe -sS -X POST "$BaseUrl/tasks" `
    -H "Authorization: Bearer $token" `
    -H "Idempotency-Key: $key" `
    -H 'Content-Type: application/json' `
    -w "`nHTTP %{http_code}`n" `
    -d '{"title":"DIFFERENT","priority":"low"}'

HR "6. Race-safety: 50 parallel POSTs with the SAME fresh key — expect exactly 1 task row"
$raceKey = NewUuid
Write-Host "Idempotency-Key=$raceKey"
Write-Host "Firing 50 parallel requests..."
$codes = 1..50 | ForEach-Object -Parallel {
    curl.exe -sS -o NUL -w "%{http_code}" `
        -X POST "$using:BaseUrl/tasks" `
        -H "Authorization: Bearer $using:token" `
        -H "Idempotency-Key: $using:raceKey" `
        -H 'Content-Type: application/json' `
        -d '{"title":"race","priority":"medium"}'
} -ThrottleLimit 50
$codes | Group-Object | Select-Object Count, Name
Write-Host ""
Write-Host "(Verify in psql:)"
Write-Host "  docker compose exec -T postgres psql -U postgres -d tasks -c ``"
Write-Host "    `"SELECT count(*) FROM idempotency_keys WHERE idempotency_key='$raceKey';`""
Write-Host "  -> expect 1"

HR "7. List Tasks (filter + search + pagination)"
curl.exe -sS -G "$BaseUrl/tasks" `
    -H "Authorization: Bearer $token" `
    --data-urlencode "status=pending" `
    --data-urlencode "q=ship" `
    --data-urlencode "page=1" `
    --data-urlencode "limit=10"
Write-Host ""

HR "8. Get one task"
curl.exe -sS "$BaseUrl/tasks/$taskId" -H "Authorization: Bearer $token"
Write-Host ""

HR "9. Update task"
curl.exe -sS -X PUT "$BaseUrl/tasks/$taskId" `
    -H "Authorization: Bearer $token" `
    -H 'Content-Type: application/json' `
    -d '{"title":"Ship the take-home (in review)","description":"reviewer is reading","status":"in_progress","priority":"high"}'
Write-Host ""

HR "10. Assign task to self (same team — succeeds, transactional)"
curl.exe -sS -X POST "$BaseUrl/tasks/$taskId/assign" `
    -H "Authorization: Bearer $token" `
    -H 'Content-Type: application/json' `
    -d "{`"assignee_id`":`"$userId`"}"
Write-Host ""

HR "11. Assign to non-existent user — expect 422 (assignee not found)"
$fakeId = NewUuid
curl.exe -sS -X POST "$BaseUrl/tasks/$taskId/assign" `
    -H "Authorization: Bearer $token" `
    -H 'Content-Type: application/json' `
    -w "`nHTTP %{http_code}`n" `
    -d "{`"assignee_id`":`"$fakeId`"}"

HR "12. Delete task (creator only)"
curl.exe -sS -X DELETE "$BaseUrl/tasks/$taskId" `
    -H "Authorization: Bearer $token" `
    -w "HTTP %{http_code}`n"

HR "Unauthorized — no token → 401"
curl.exe -sS "$BaseUrl/tasks" -w "`nHTTP %{http_code}`n"
