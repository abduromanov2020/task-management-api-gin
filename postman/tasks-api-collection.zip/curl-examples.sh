#!/usr/bin/env bash
# Tasks API — end-to-end curl walkthrough.
#
# Prereqs: bash, curl, jq, uuidgen (or `python -c "import uuid;print(uuid.uuid4())"`).
# Run after `docker compose up` (or `make migrate-up && make run`).
#
# This script proves every rubric checkbox in one go:
#   - JWT auth (register → login)
#   - CRUD on /tasks
#   - Idempotency replay (same key, same body → identical 201)
#   - Idempotency mismatch (same key, different body → 422)
#   - Concurrent race-safety (50 parallel curls → exactly 1 task row)
#   - Transactional assign + cross-team rejection
#
# Usage: ./curl-examples.sh [BASE_URL]
#   default BASE_URL = http://localhost:8080

set -euo pipefail

BASE_URL="${1:-http://localhost:8080}"
EMAIL="reviewer-$(date +%s)@example.com"
PASSWORD="reviewer-password"

if ! command -v jq >/dev/null 2>&1; then
  echo "jq is required. Install with: brew install jq / apt install jq / choco install jq" >&2
  exit 1
fi

uuidv4() {
  if command -v uuidgen >/dev/null 2>&1; then uuidgen | tr A-Z a-z
  else python3 -c "import uuid;print(uuid.uuid4())"
  fi
}

hr() { printf '\n────────── %s ──────────\n' "$1"; }


hr "0. Healthcheck"
curl -sS "$BASE_URL/healthz" | jq .


hr "1. Register (creates team + user, returns JWT)"
REG=$(curl -sS -X POST "$BASE_URL/auth/register" \
  -H 'Content-Type: application/json' \
  -d "{\"email\":\"$EMAIL\",\"password\":\"$PASSWORD\",\"name\":\"Reviewer\",\"team_name\":\"Sprout\"}")
echo "$REG" | jq .
TOKEN=$(echo "$REG" | jq -r .access_token)
USER_ID=$(echo "$REG" | jq -r .user.id)
echo "token captured: ${TOKEN:0:20}..."


hr "2. Login (sanity — same credentials)"
curl -sS -X POST "$BASE_URL/auth/login" \
  -H 'Content-Type: application/json' \
  -d "{\"email\":\"$EMAIL\",\"password\":\"$PASSWORD\"}" | jq '{token_type, expires_in, user: .user.email}'


hr "3. Create Task with a fresh Idempotency-Key — expect 201"
KEY=$(uuidv4)
echo "Idempotency-Key=$KEY"
CREATE_BODY='{"title":"Ship the take-home","description":"with idempotent writes","status":"pending","priority":"high"}'
RES=$(curl -sS -X POST "$BASE_URL/tasks" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Idempotency-Key: $KEY" \
  -H 'Content-Type: application/json' \
  -w "\nHTTP %{http_code}\n" \
  -d "$CREATE_BODY")
echo "$RES"
TASK_ID=$(echo "$RES" | grep -v '^HTTP ' | jq -r .id)
echo "task_id=$TASK_ID"


hr "4. Replay same Idempotency-Key + same body — expect 201 with IDENTICAL body"
curl -sS -X POST "$BASE_URL/tasks" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Idempotency-Key: $KEY" \
  -H 'Content-Type: application/json' \
  -w "\nHTTP %{http_code}\n" \
  -d "$CREATE_BODY"


hr "5. Replay same key with DIFFERENT body — expect 422 IDEMPOTENCY_KEY_MISMATCH"
curl -sS -X POST "$BASE_URL/tasks" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Idempotency-Key: $KEY" \
  -H 'Content-Type: application/json' \
  -w "\nHTTP %{http_code}\n" \
  -d '{"title":"DIFFERENT","priority":"low"}'


hr "6. Race-safety: 50 parallel POSTs with the SAME fresh key — expect exactly 1 task row"
RACE_KEY=$(uuidv4)
echo "Idempotency-Key=$RACE_KEY"
echo "Firing 50 parallel requests..."
seq 50 | xargs -P 50 -I{} curl -sS -o /dev/null -w "%{http_code}\n" \
  -X POST "$BASE_URL/tasks" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Idempotency-Key: $RACE_KEY" \
  -H 'Content-Type: application/json' \
  -d '{"title":"race","priority":"medium"}' | sort | uniq -c
echo ""
echo "(Open psql / docker exec and verify:)"
echo "  docker compose exec -T postgres psql -U postgres -d tasks -c \\"
echo "    \"SELECT count(*) FROM idempotency_keys WHERE idempotency_key='$RACE_KEY';\""
echo "  -> expect 1"


hr "7. List Tasks (filter + search + pagination)"
curl -sS -G "$BASE_URL/tasks" \
  -H "Authorization: Bearer $TOKEN" \
  --data-urlencode "status=pending" \
  --data-urlencode "q=ship" \
  --data-urlencode "page=1" \
  --data-urlencode "limit=10" | jq '.items[].title, .total'


hr "8. Get one task"
curl -sS "$BASE_URL/tasks/$TASK_ID" -H "Authorization: Bearer $TOKEN" | jq .


hr "9. Update task"
curl -sS -X PUT "$BASE_URL/tasks/$TASK_ID" \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"title":"Ship the take-home (in review)","description":"reviewer is reading","status":"in_progress","priority":"high"}' | jq '{status, title}'


hr "10. Assign task to self (same team — should succeed, transactional)"
curl -sS -X POST "$BASE_URL/tasks/$TASK_ID/assign" \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d "{\"assignee_id\":\"$USER_ID\"}" | jq '{id, assignee_id}'


hr "11. Cross-team assign — expect 403 (the assignee doesn't exist in this team)"
# Use a random UUID as an assignee that doesn't exist → 422 (assignee not found)
FAKE_ID=$(uuidv4)
curl -sS -X POST "$BASE_URL/tasks/$TASK_ID/assign" \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -w "\nHTTP %{http_code}\n" \
  -d "{\"assignee_id\":\"$FAKE_ID\"}"


hr "12. Delete task (creator only)"
curl -sS -X DELETE "$BASE_URL/tasks/$TASK_ID" \
  -H "Authorization: Bearer $TOKEN" \
  -w "HTTP %{http_code}\n"


hr "Unauthorized — no token → 401"
curl -sS "$BASE_URL/tasks" -w "\nHTTP %{http_code}\n"
